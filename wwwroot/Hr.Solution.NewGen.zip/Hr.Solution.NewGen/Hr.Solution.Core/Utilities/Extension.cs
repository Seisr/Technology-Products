﻿using Hr.Solution.Data.Requests;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hr.Solution.Core.Utilities
{
   public static class Extension
    {
        
    }
}
