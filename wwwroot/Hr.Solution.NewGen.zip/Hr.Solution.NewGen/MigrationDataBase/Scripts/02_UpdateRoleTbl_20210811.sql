GO
ALTER TABLE [dbo].[sys_Roles]
ADD RoleSubName nvarchar(100)