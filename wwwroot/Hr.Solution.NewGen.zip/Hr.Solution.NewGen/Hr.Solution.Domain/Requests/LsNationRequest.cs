﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hr.Solution.Domain.Requests
{
  public class LsNationRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
