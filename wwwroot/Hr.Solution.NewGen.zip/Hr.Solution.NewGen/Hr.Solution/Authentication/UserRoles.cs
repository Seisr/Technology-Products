﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hr.Solution.Application.Authentication
{
    public static class UserRoles
    {
        public const string Admin = "ADMIN";
        public const string IndividualUser = "INV_USER";
    }
}
