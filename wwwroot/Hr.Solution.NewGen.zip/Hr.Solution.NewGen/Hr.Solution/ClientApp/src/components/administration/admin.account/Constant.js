export class Mode {
    static CREATE = 1;
    static EDIT =2;
}

export class PasswordType{
    static Default =1;
    static Custom =2;
}

export class DefaultPassword{
    static value="Hr@123";
}