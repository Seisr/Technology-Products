export class Mode {
    static CREATE = 1;
    static EDIT =2;
    static VIEW =3;
}