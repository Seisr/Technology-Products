export class TabType{
    static USER = 1;
    static ROLE =2;
}

export class Action {
    static CREATE = 1;
    static EDIT =2;
}

export class FunctionType {
    static Module ="M";
    static Function ="S";
}