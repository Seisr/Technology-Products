export class SelectMode {
    static Single =1;
    static Multiple =2;
}

export class Type{
    static Select = 1;
    static Module = 2;
}