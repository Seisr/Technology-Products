export class TabType{
    static ROLE = 1;
    static DEPARTMENT =2;
}

export class Action {
    static CREATE = 1;
    static EDIT =2;
}

export class FunctionType {
    static Module ="M";
    static Function ="S";
}