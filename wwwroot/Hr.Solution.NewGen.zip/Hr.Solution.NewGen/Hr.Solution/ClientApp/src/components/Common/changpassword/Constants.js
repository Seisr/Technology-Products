export class ErrorCase{
    static oldPassMatchNewPass = "Mật khẩu mới không được trùng mật khẩu cũ!";
    static confirmNotMatchNewPass = "Mật khẩu xác nhận không trùng khớp!";
    static fieldNull = "Vui lòng điền đầy đủ các trường!";
    static 
}
