export class NotificationType {
    static SUCCESS ="success";
    static ERROR ="danger";
    static WARNING ="warning";
    static INFO ="info";
    static DEFAULT ="default";
}