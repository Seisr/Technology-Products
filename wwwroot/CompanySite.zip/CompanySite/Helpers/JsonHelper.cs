﻿using System.Text.Json;
using System.Text.Json.Serialization;

using CompanySite.Models;

namespace CompanySite;

public class JsonHelper
{
  private readonly string _jsonFilePath;

  private readonly JsonSerializerOptions _options = new()
  {
    PropertyNameCaseInsensitive = true,
    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
  };

  public JsonHelper(string jsonFilePath)
  {
    _jsonFilePath = jsonFilePath;
  }

  public async Task<RootModel> ReadAsync()
  {
    using FileStream json = File.OpenRead(_jsonFilePath);
    RootModel? rootModel = await JsonSerializer.DeserializeAsync<RootModel>(json, _options);
    if (rootModel == null)
    {
      return default!;
    }
    return rootModel;
  }

  public async Task WriteMessageAsync(List<ContactModel> models)
  {
    List<ContactModel>? existingModels;

    // Check if the file exists
    if (File.Exists(_jsonFilePath))
    {
      // Read the existing data from the file
      await using FileStream readFileStream = File.OpenRead(_jsonFilePath);
      existingModels = await JsonSerializer.DeserializeAsync<List<ContactModel>>(readFileStream);
    }
    else
    {
      existingModels = new List<ContactModel>();
    }

    if (existingModels is null)
    {
      existingModels = new();
    }

    // Add the new data to the existing data
    existingModels.AddRange(models);

    // Write the updated data back to the file
    await using FileStream writeFileStream = File.Create(_jsonFilePath);
    await JsonSerializer.SerializeAsync(writeFileStream, existingModels);
  }
}
