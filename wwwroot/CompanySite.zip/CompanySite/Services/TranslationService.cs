﻿namespace CompanySite.Services
{
  public class TranslationService
  {
    public RootModel RootModel { get; private set; }
    private readonly IWebHostEnvironment _environment;

    public TranslationService(IWebHostEnvironment environment)
    {
      RootModel = new RootModel();
      _environment = environment;
    }

    public async Task SetTranslatedContentAsync(string fileName)
    {
      string jsonPath = Path.Combine(_environment.ContentRootPath, "wwwroot", "json", fileName);
      JsonHelper jsonHelper = new(jsonPath);
      RootModel = await jsonHelper.ReadAsync();
    }
  }
}
