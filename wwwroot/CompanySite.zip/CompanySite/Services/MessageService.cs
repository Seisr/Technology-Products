﻿using CompanySite.Models;

namespace CompanySite.Services
{
  public class MessageService
  {
    public List<ContactModel> Contacts { get; private set; } = new();
    private readonly IWebHostEnvironment _environment;

    public MessageService(IWebHostEnvironment environment)
    {
      _environment = environment;
    }

    public async Task WriteAsync(ContactModel model)
    {
      var storedMsgPath = Path.Combine(_environment.ContentRootPath, "wwwroot", "json", "Message.json");
      JsonHelper jsonHelper = new(storedMsgPath);
      Contacts.Add(model);
      await jsonHelper.WriteMessageAsync(Contacts);
    }
  }
}
