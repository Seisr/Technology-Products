﻿using System.Globalization;

namespace CompanySite.Services;

public class CultureChangeService
{
  public CultureInfo CurrentCulture { get; private set; } = CultureInfo.CurrentCulture;

  public void SetCurrentCulture(CultureInfo newCulture)
  {
    if (newCulture == CurrentCulture)
    {
      return;
    }
    CurrentCulture = newCulture;
    Thread.CurrentThread.CurrentCulture.ClearCachedData();
    Thread.CurrentThread.CurrentUICulture.ClearCachedData();
    Thread.CurrentThread.CurrentCulture = newCulture;
    Thread.CurrentThread.CurrentUICulture = newCulture;
  }

  public CultureInfo GetCurrentCulture()
  {
    if (CurrentCulture is null)
    {
      SetCurrentCulture(CultureInfo.CurrentCulture);
    }
    return CurrentCulture!;
  }
}
