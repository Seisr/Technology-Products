﻿namespace CompanySite;

public class HistoryModel
{
  public int Id { get; set; }
  public string Title { get; set; } = default!;
  public string Content { get; set; } = default!;
  public string Description { get; set; } = default!;
}
