﻿namespace CompanySite;

public class VisionModel
{
  public int Id { get; set; }
  public string Title { get; set; } = default!;
  public string Content { get; set; } = default!;
  public string Icon { get; set; } = default!;
}
