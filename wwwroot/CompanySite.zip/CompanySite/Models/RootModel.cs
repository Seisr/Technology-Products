﻿namespace CompanySite;

public class RootModel
{
  public List<ServiceModel> Services { get; set; } = new();
  public List<VisionModel> Visions { get; set; } = new();
  public List<HistoryModel> Histories { get; set; } = new();
}
