﻿namespace CompanySite.Constants;

public static class JsonFileConstant
{
  public const string EN_US = "ContentData.en-US.json";
  public const string VI = "ContentData.vn-VN.json";
  public const string KO = "ContentData.kr-KR.json";
}
